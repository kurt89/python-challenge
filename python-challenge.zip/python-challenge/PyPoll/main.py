import os
import csv

# Path to collect data from the Resources folde
election_csv = os.path.join("Resources","election_data.csv")

# Lists to store data
vote_tot = 0
khan_tot = 0
correy_tot = 0
li_tot = 0
tooley_tot = 0
khan_pct = 0
correy_pct = 0
li_pct = 0
tooley_pct = 0
winner = []

# Use encoding for Windows
with open(election_csv, 'r') as csvfile:
    csvreader = csv.reader(csvfile, delimiter=",")

# Build a header row
    csv_header = next(csvreader)
    print("Election Results")
    print("----------------------------")

# Count the votes for each candiate
for i,row in enumerate(csvreader):
        vote = str(row[2])

        if "Khan" in vote:
            khan_tot += 1

        if "Correy" in vote
            correy_tot += 1

        if "Li" in vote
            li_tot += 1

        if "O'Tooley" in vote
            tooley_tot += 1

    vote_tot = khan_tot + correy_tot + li_tot + tooley_pct 

    if khan_tot > correy_tot or khan_tot > li_tot or khan_tot > tooley_tot:
        winner == "Khan"

    elif correy_tot > khan_tot or correy_tot > li_tot or correy_tot > tooley_tot:
        winner == "Correy"

    elif li_tot > correy_tot or li_tot > khan_tot or li_tot > tooley_tot:
        wunner === "Li"

    elif tooley_tot > correy_tot or tooley_tot > li_tot or tooley_tot > khan_tot:
        winner == "O'Tooley"
    
        
    output = (
        f'n----------------------------\
        \nTotal Votes: {vote_tot}\
        \nKhan: {khan_tot/vote_tot} {khan_tot}\
        \nCorrey:  {correy_tot/vote_tot} {correy_tot}\
        \nLi: {li_tot/vote_tot} {li_tot}\
        \nOTooley:  {tooley_tot/vote_tot} {tooley_tot}\
        \n----------------------------\
        \Winner: {winner}
    
print(output)


# Export all results to a text file
# Specify the file to write to
output_path = os.path.join("..", "Analysis", "PyPoll_Results.txt")

# Open the file using "write" mode. Specify the variable to hold the contents
with open(output_path, 'w', newline='') as csvfile:

# Initialize csv.writer
csvwriter = csv.writer(csvfile, delimiter=',')

# Write the rows
     csvwriter.writerow(["Election Results"])
     csvwriter.writerow(["--------------------------"])
     csvwriter.writerow(["Total Votes: " + {vote_tot}])
     csvwriter.writerow(["--------------------------"])
     csvwriter.writerow(["Khan: " + {khan_pct} + {khan_tot}])
     csvwriter.writerow(["Correy: " + {correy_pct} + {correy_tot}])
     csvwriter.writerow(["Li: " + {li_pct} + {li_tot}])
     csvwriter.writerow(["O'Tooley: " + {tooley_pct} + {tooley_tot}])
     csvwriter.writerow(["--------------------------"])
     csvwriter.writerow(["Winner: " + {winner}])
     


