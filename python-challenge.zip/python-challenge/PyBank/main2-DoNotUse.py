import os
import csv

# Path to collect data from the Resources folde
budget_csv = os.path.join("Resources","budget_data.csv")

# Lists to store data
date = []
profit_loss = []
profit_loss_1st = []
profit_loss_2nd = []
profit_total=[]
greatest_inc=[]
greatest_dec=[]

# Use encoding for Windows
# with open(budget_csv, newline='', encoding='utf-8') as csvfile:
with open(budget_csv, 'r') as csvfile:
    csvreader = csv.reader(csvfile, delimiter=",")
    print(csvreader)

# Build a header row
    csv_header = next(csvreader)
    print("Financial Analysis")
    print("----------------------------")

# Count the total number of months
    lines = len(list(csvreader))
    print("Total Months: " + str(lines))

# define "total_list" as the numbers in the 2nd column of the data file
total_list = []
total = []
# total_list = budget_csv(row[1])
for x in total_list:
    x_total = 0
    for y in x:
        x_total = int(y) + x_total
    print(x_total)
    total = x_total + total
print("Total: "+ str(total))

# Determine the month-to-month changes in profit/loss
# Create a loop starting on the second value
diff_list = []
change = []
for row in range(1, len(total_list)):
    # Create a variable (x) to grab current minus previous value
    row_total = 0
    for x in row:
        row_total = int(total_list[row]) - int(total_list[row-1])
        print(row_total)
        change = row_total + change
    change.append(x)
print(change)

# Find and print the average and round it to 2 decimal points
average = round(sum(diff_list)/len(change),2)
print("Average Change: " + str(average))

# Find the greatest profit increases and decreases
greatest_inc = max(diff_list)
greatest_dec = min(diff_list)

# Index the Month with the greatest increase in profits 
r = 0
month_row_val = []
for row in diff_list:
    if int(diff_list(row[1])) == greatest_inc:
        r = row[0]
    month_row_val.append(r)
print(month_row_val)

# Print the month and its (greatest) increase in profits
print("Greatest Increase in Profits: " + str(month_row-val) + str(greatest_inc))

# Index the Month with the greatest decrease in profits 
r = 0
month_row_val = []
for row in diff_list:
    if int(diff_list(row[1])) == greatest_dec:
        r = row[0]
    month_row_val.append(r)
print(month_row_val)

# Print the month and its (greatest) decrease in profits
print("Greatest Decrease in Profits: " + str(month_row-val) + str(greatest_dec))

# Export all results to a text file
# Specify the file to write to
output_path = os.path.join("..", "Analysis", "PyBank_Results.csv")

# Open the file using "write" mode. Specify the variable to hold the contents
with open(output_path, 'w', newline='') as csvfile:

    # Initialize csv.writer
    csvwriter = csv.writer(csvfile, delimiter=',')

    # Write the first row (header)
    csvwriter.writerow(["Financial Analysis"])

    # Write the second row (spaces)
    csvwriter.writerow(["--------------------------"])

    # Write the third rowCaleb', 'Frost',
    csvwriter.writerow(["Total Months: " + str(lines)])

    # Write the fourth row
    csvwriter.writerow(["Average Change: " + str(average)])

    # Write the fifth row
    csvwriter.writerow(["Greatest Increase in Profits: " + str(month_row-val) + str(greatest_inc)])

    # Write the sixth row
    csvwriter.writerow(["Greatest Decrease in Profits: " + str(month_row-val) + str(greatest_dec)])

# Read each row of data following the header
    # for row in csvreader:
       # profit_total.append(row[1])
       # profit_total =+ int(row[1])
    # print(profit_total)
    # print({sum(profit_total)})
    # print("Total: " + str[sum(profit_total)])

# Net "Profit/Loss" total over all months

# Determine "Profit/Loss" changes, each month versus period, then calculate the average of all changes
# def average(numbers):
    # length = len(numbers)
    # total = 0.0
    # for number in numbers:
        # total += number
    # return total / length
# print(str(total / lines))

# Test your function with the following:
# print(average([1, 5, 9]))
# print(average(range(11)))


