import os
import csv

# Path to collect data from the Resources folde
budget_csv = os.path.join("Resources","budget_data.csv")

# Lists to store data
months = 0
total = 0
prev_rev = 0
total_ch = 0
inc = ['',0]
dec = ['',1000000]

# Use encoding for Windows
# with open(budget_csv, newline='', encoding='utf-8') as csvfile:
with open(budget_csv, 'r') as csvfile:
    csvreader = csv.reader(csvfile, delimiter=",")

# Build a header row
    csv_header = next(csvreader)
    print("Financial Analysis")
    print("----------------------------")

    for i,row in enumerate(csvreader):
        rev = int(row[1])
        months += 1
        total += rev
        
        change = rev - prev_rev
        
        if i == 0:
            change = 0
        total_ch += change
        prev_rev = rev
        
        if change > inc[1]:
            inc[0] = row[0]
            inc[1] = change

        if change < inc[1]:
            dec[0] = row[0]
            dec[1] = change

    output = (
        f'\nTotal Months: {months} \
        \nTotal: ${total:,}\
        \nAverage  Change: ${total_ch/(months-1):,.2f}\
        \nGreatest Increase in Profits: {inc[0]} (${inc[1]:,})\
        \nGreatest Decrease in Profits: {dec[0]} (${dec[1]:,})\

print(output)

# Export all results to a text file
# Specify the file to write to
output_path = os.path.join("..", "Analysis", "PyBank_Results.txt")

# Open the file using "write" mode. Specify the variable to hold the contents
with open(output_path, 'w', newline='') as csvfile:

# Initialize csv.writer
csvwriter = csv.writer(csvfile, delimiter=',')

# Write the rows
     csvwriter.writerow(["Financial Analysis"])
     csvwriter.writerow(["--------------------------"])
     csvwriter.writerow(["Total Months: " + {months}])
     csvwriter.writerow(["Total: " + ${total:,}])
     csvwriter.writerow(["Average Change: " + ${total_ch/(months-1):,.2f}])
     csvwriter.writerow(["Greatest Increase in Profits: " + {inc[0]}, (${inc[1]:,}])
     csvwriter.writerow(["Greatest Decrease in Profits: " + {dec[0]}, (${dec[1]:,})])



